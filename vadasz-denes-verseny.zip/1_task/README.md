# Feladat

Magyar tudósok, feltalálók életútjának és munkásságának bemutatása.