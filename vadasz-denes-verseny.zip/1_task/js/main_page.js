const heading = 'Magyar tudósok és feltalálók';
let i = 0;
let extended = true;
let extended_fields = true;
let extended_list = false;
let filters = document.getElementsByClassName("filt");
let cards = document.getElementsByClassName("card");

//Typing animation on title
const typing = function() {
    if (i < heading.length) {
        document.querySelector('.title').innerHTML += heading.charAt(i);
        i++;

        setTimeout(typing, 80);
    }
}
typing();

//Extend era-filters' list
document.querySelector('.extend-eras').addEventListener('click', () => {
    if (extended) {
        extended = false;
        document.querySelector('.era-filters').style.visibility = 'hidden';
        document.querySelector('.era-filters').style.opacity = '0';
        document.querySelector('.extend-eras').innerHTML = '+';
        document.querySelector('.fields').style.top = '40px';
        document.querySelector('.fields').style.transition = 'top .3s .3s';
        document.querySelector('.era-filters').style.transition = 'all .3s';
    } else {
        extended = true
        document.querySelector('.era-filters').style.visibility = 'visible';
        document.querySelector('.era-filters').style.opacity = '1';
        document.querySelector('.extend-eras').innerHTML = '-';
        document.querySelector('.fields').style.top = '150px';
        document.querySelector('.era-filters').style.transition = 'all .3s .2s';
        document.querySelector('.fields').style.transition = 'top .3s';
    }
    
})

//Extend field-filters' list
document.querySelector('.extend-fields').addEventListener('click', () => {
    if (extended_fields) {
        extended_fields = false;
        document.querySelector('.field-filters').style.visibility = 'hidden';
        document.querySelector('.field-filters').style.opacity = '0';
        document.querySelector('.extend-fields').innerHTML = '+';
        document.querySelector('.list').style.top = '-80px';
    } else {
        extended_fields = true
        document.querySelector('.field-filters').style.visibility = 'visible';
        document.querySelector('.field-filters').style.opacity = '1';
        document.querySelector('.extend-fields').innerHTML = '-';
        document.querySelector('.list').style.top = '80px';
    }
    
})

//Set visibleByYear and visibleByArea attribute to true
document.addEventListener("DOMContentLoaded", function (event) {
    let cards = document.getElementsByClassName("card");

    for(let g = 0; g < cards.length; g++) {
        cards[g].setAttribute("visibleByYear", true);
        cards[g].setAttribute("visibleByArea", true);
     }
})

//Check if both of the visibleByYear and visibleByArea attributes are true, if true show card, else don't show
function refreshCardVisibility() {
    let cards = document.getElementsByClassName("card");

    for(let g = 0; g < cards.length; g++) {
        let visibleByYear = cards[g].getAttribute("visibleByYear");
        let visibleByArea = cards[g].getAttribute("visibleByArea");

        if (visibleByYear == 'true' && visibleByArea == 'true') {
            cards[g].style.visibility = 'visible';
            cards[g].style.position = 'relative';
        } else {
            cards[g].style.visibility = 'hidden';
            cards[g].style.position = 'absolute';
        }
        cards[g].style.transition = 'transform .3s';
    }
}

//Clearing the filters
document.querySelector(".clear").addEventListener("click", () => {
    for (let i = 0; i < filters.length; i++) {
        filters[i].checked = true
        refreshCardVisibility()
    }

    for (let a = 0; a < cards.length; a++) {
        cards[a].setAttribute("visibleByYear", true);
        cards[a].setAttribute("visibleByArea", true);
        refreshCardVisibility()
    }
})

//Goupping scientists by the era they worked in and the field they worked in
let group_1800_1900 = document.getElementsByClassName('group-1800-1900');
let group_1901_2000 = document.getElementsByClassName('group-1901-2000');
let group_2001_2023 = document.getElementsByClassName('group-2001-2023');
let group_chemist = document.getElementsByClassName('group-chemist');
let group_physics = document.getElementsByClassName('group-physics');
let group_biology = document.getElementsByClassName('group-biology');
let group_geography = document.getElementsByClassName('group-geography');

//Filtering cards with group-1800-1900 class
document.querySelector('input[id=filter1]').addEventListener('change', function () {
    for (let i = 0; i < group_1800_1900.length; i++) {
        group_1800_1900[i].setAttribute("visibleByYear", this.checked);
    }
    refreshCardVisibility();
});

//Filtering cards with group-1901-2000 class
document.querySelector('input[id=filter2]').addEventListener('change', function () {
    for (let i = 0; i < group_1901_2000.length; i++) {
        group_1901_2000[i].setAttribute("visibleByYear", this.checked);
    }
    refreshCardVisibility();
});

//Filtering cards with group-2001-2023 class
document.querySelector('input[id=filter3]').addEventListener('change', function () {
    for (let i = 0; i < group_2001_2023.length; i++) {
        group_2001_2023[i].setAttribute("visibleByYear", this.checked);
    }
    refreshCardVisibility();
});

//Filtering cards with group-chemist class
document.querySelector('input[id=filter4]').addEventListener('change', function () {
    for (let i = 0; i < group_chemist.length; i++) {
        group_chemist[i].setAttribute("visibleByArea", this.checked);
    }
    refreshCardVisibility();
});

//Filtering cards with group-physics class
document.querySelector('input[id=filter5]').addEventListener('change', function () {
    for (let i = 0; i < group_physics.length; i++) {
        group_physics[i].setAttribute("visibleByArea", this.checked);
    }
    refreshCardVisibility();
});

//Filtering cards with group-biology class
document.querySelector('input[id=filter6]').addEventListener('change', function () {
    for (let i = 0; i < group_biology.length; i++) {
        group_biology[i].setAttribute("visibleByArea", this.checked);
    }
    refreshCardVisibility();
});

//Filtering cards with group-geography class
document.querySelector('input[id=filter7]').addEventListener('change', function () {
    for (let i = 0; i < group_geography.length; i++) {
        group_geography[i].setAttribute("visibleByArea", this.checked);
    }
    refreshCardVisibility();
});


const names = document.getElementsByClassName("name");

//Finding the name typed in the searchbar
function search () {
    let input = document.getElementById("searchbar").value;
    let first_occurance = null;

    for (let f = 0; f < names.length; f++) {
        let regExp = new RegExp(input, "gi");

        if (regExp.test(names[f].textContent)) {
            names[f].innerHTML = (names[f].textContent).replace(regExp, "<mark>$&</mark>");

            if (first_occurance == null) {
                first_occurance = names[f];
            }
        }
    }

    //Jump to the first selected value
    var element = first_occurance.parentElement;
    var position = element.getBoundingClientRect();
    var x = position.left;
    var y = position.top;
    window.scrollBy(x, y);
}

