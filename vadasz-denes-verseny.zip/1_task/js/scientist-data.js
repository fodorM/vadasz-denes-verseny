const slides = document.getElementsByClassName("slide");

let right_arrow_counter = 3;
let left_arrow_counter = 0;
let slide_counter = 0;

//Navigating to the next slide
document.querySelector(".arrow-right").addEventListener("click", () => {
    if (right_arrow_counter > 0) {
        slides[slide_counter].style.opacity = "0";
        slides[slide_counter].style.visibility = "hidden";
        slides[slide_counter].style.transition = "all 1.5s";

        slides[slide_counter + 1].style.opacity = "1";
        slides[slide_counter + 1].style.visibility = "visible";
        slides[slide_counter + 1].style.transition = "all 1.5s .5s";
        
        right_arrow_counter--
        left_arrow_counter++
        slide_counter++
    }
})

//Navigating to the previous slide
document.querySelector(".arrow-left").addEventListener("click", () => {
    if (left_arrow_counter > 0) {
        slides[slide_counter].style.opacity = "0";
        slides[slide_counter].style.visibility = "hidden";
        slides[slide_counter].style.transition = "all 1.5s";

        slides[slide_counter - 1].style.opacity = "1";
        slides[slide_counter - 1].style.visibility = "visible";
        slides[slide_counter - 1].style.transition = "all 1.5s .5s";
        
        right_arrow_counter++
        left_arrow_counter--
        slide_counter--
    }
})