//Tracking the number of correct and incorrect answers
let correct = 0;
let incorrect = 0;

let wrappers = document.getElementsByClassName("wrapper");
let numbers = document.getElementsByClassName("number");

//User selecting the answer in each question
for (let a = 1; a < 6; a++) {
    for (let b = 1; b < 4; b++) {
        document.querySelector(".question" + CSS.escape(a) + "-answer" + CSS.escape(b)).addEventListener("click", () => {
            if (document.querySelector(".question" + CSS.escape(a) + "-answer" + CSS.escape(b)).getAttribute("right") == "true") {
                document.querySelector(".question" + CSS.escape(a) + "-answer" + CSS.escape(b)).style.backgroundColor = "lightgreen";
                correct++;
                if (a == 5) {
                    document.querySelector(".score-wrapper").style.cssText = "visibility: visible; opacity: 1; transition: all .5s .8s";
                    document.querySelector(".incorrect").innerHTML += "<span style=\"color:red\">" + incorrect + "</span>";
                    document.querySelector(".correct").innerHTML += "<span style=\"color:green\">" + correct + "</span>";
                }
                if (a !== 5) { 
                    document.querySelector(".number" + CSS.escape(a + 1)).style.pointerEvents = "all";
                }
            } else {
                document.querySelector(".question" + CSS.escape(a) + "-answer" + CSS.escape(b)).style.backgroundColor = "lightcoral";
                incorrect ++;
                if (a == 5) {
                    document.querySelector(".score-wrapper").style.cssText = "visibility: visible; opacity: 1; transition: all .5s .8s";
                    document.querySelector(".incorrect").innerHTML += "<span style=\"color:red\">" + incorrect + "</span>";
                    document.querySelector(".correct").innerHTML += "<span style=\"color:green\">" + correct + "</span>";
                }
                if (a !== 5) { 
                    document.querySelector(".number" + CSS.escape(a + 1)).style.pointerEvents = "all";
                }
            }
            for (let c = 1; c < 4; c++) {
                document.querySelector(".question" + CSS.escape(a) + "-answer" + CSS.escape(c)).style.pointerEvents = "none";
            }
        })
    }   
}

//Moving to next question
document.querySelector(".number1").addEventListener("click", () => {
    for (let i = 0; i < 5; i++) {
        if (i !== 0) {
            wrappers[i].style.opacity = "0";
            wrappers[i].style.visibility = "hidden";
            wrappers[i].style.transition = "all .5s";
            numbers[i].style.backgroundColor = "orange";
        }
    }
    wrappers[0].style.visibility = "visible";
    wrappers[0].style.opacity = "1";
    wrappers[0].style.transition = "all .5s .6s";
    numbers[0].style.backgroundColor = "green";
});

//Moving to next question
document.querySelector(".number2").addEventListener("click", () => {
    for (let i = 0; i < 5; i++) {
        if (i !== 1) {
            wrappers[i].style.opacity = "0";
            wrappers[i].style.visibility = "hidden";
            wrappers[i].style.transition = "all .5s";
            numbers[i].style.backgroundColor = "orange";
        }
    }
    wrappers[1].style.visibility = "visible";
    wrappers[1].style.opacity = "1";
    wrappers[1].style.transition = "all .5s .6s";
    numbers[1].style.backgroundColor = "green";
    numbers[0].style.pointerEvents = "all";
});

//Moving to next question
document.querySelector(".number3").addEventListener("click", () => {
    for (let i = 0; i < 5; i++) {
        if (i !== 2) {
            wrappers[i].style.opacity = "0";
            wrappers[i].style.visibility = "hidden";
            wrappers[i].style.transition = "all .5s";
            numbers[i].style.backgroundColor = "orange";
        }
    }
    wrappers[2].style.visibility = "visible";
    wrappers[2].style.opacity = "1";
    wrappers[2].style.transition = "all .5s .6s";
    numbers[2].style.backgroundColor = "green";
});

//Moving to next question
document.querySelector(".number4").addEventListener("click", () => {
    for (let i = 0; i < 5; i++) {
        if (i !== 3) {
            wrappers[i].style.opacity = "0";
            wrappers[i].style.visibility = "hidden";
            wrappers[i].style.transition = "all .5s";
            numbers[i].style.backgroundColor = "orange";
        }
    }
    wrappers[3].style.visibility = "visible";
    wrappers[3].style.opacity = "1";
    wrappers[3].style.transition = "all .5s .6s";
    numbers[3].style.backgroundColor = "green";
});

//Moving to next question
document.querySelector(".number5").addEventListener("click", () => {
    for (let i = 0; i < 5; i++) {
        if (i !== 4) {
            wrappers[i].style.opacity = "0";
            wrappers[i].style.visibility = "hidden";
            wrappers[i].style.transition = "all .5s";
            numbers[i].style.backgroundColor = "orange";
        }
    }
    wrappers[4].style.visibility = "visible";
    wrappers[4].style.opacity = "1";
    wrappers[4].style.transition = "all .5s .6s";
    numbers[4].style.backgroundColor = "green";
});

//Closing the window that shows the final score of the quiz
document.querySelector(".close").addEventListener("click", () => {
    document.querySelector(".score-wrapper").style.visibility =  "hidden";
    document.querySelector(".score-wrapper").style.transition =  "all 0s";
    document.querySelector(".score-wrapper").style.opacity =  "0";
})

//Showing the correct answers
document.querySelector(".show-answers").addEventListener("click", () => {
    document.querySelector(".score-wrapper").style.visibility =  "hidden";
    document.querySelector(".score-wrapper").style.transition =  "all 0s";
    document.querySelector(".score-wrapper").style.opacity =  "0";
    for (let i = 0; i < 5; i++) {
        if (i !== 4) {
            numbers[i].style.backgroundColor = "orange";
        }
    }
    for (let a = 1; a < 6; a++) {
        for (let b = 1; b < 4; b++) {
            if (document.querySelector(".question" + CSS.escape(a) + "-answer" + CSS.escape(b)).getAttribute("right") == "true") {
                document.querySelector(".question" + CSS.escape(a) + "-answer" + CSS.escape(b)).style.backgroundColor = "lightgreen";
            }
        }   
    }
})
