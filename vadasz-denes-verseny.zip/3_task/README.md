# Feladat

Dinamikusan felépülő kvíz.
Kérdések hozzáadása a data.js fájlban lehetséges.
