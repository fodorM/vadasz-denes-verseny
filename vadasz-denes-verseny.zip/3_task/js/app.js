//Extracting data from data.js and making questions and answer choices from it
directive = {
    '.question-wrapper': {
        'qst<-questions': {
            '.question': 'qst.question',
            '.opt1': 'qst.option1.answer',
            '.opt1@right': 'qst.option1.right',
            '.opt2': 'qst.option2.answer',
            '.opt2@right': 'qst.option2.right',
            '.opt3': 'qst.option3.answer',
            '.opt3@right': 'qst.option3.right'
        }
    }
}

$p('.quiz-result').render(data, directive);

let questions = document.getElementsByClassName("question-wrapper");
let question_counter = 1
let current_question = 0;
let correct = 0;
let incorrect = 0;

document.querySelector(".next").style.pointerEvents = "none";
document.querySelector(".prev").style.pointerEvents = "none";
document.querySelector(".next").style.backgroundColor = "lightcoral";
document.querySelector(".prev").style.backgroundColor = "lightcoral";

document.querySelector(".question-counter").innerHTML = question_counter  + "/" + questions.length

for (let i = 0; i < questions.length; i++) {
    if (i !== 0) {
        questions[i].style.cssText = "visibility: hidden; opacity: 0";
    } else {
        questions[0].style.cssText = "visibility: visible; opacity: 1";
    }
}

//User selecting answers in each question
for (let i = 0; i < questions.length; i++) {
    let options = questions[i].getElementsByClassName("opt");
    for (let a = 0; a < options.length; a++) {
        options[a].addEventListener("click", () => {
            if (options[a].getAttribute("right") == "true") {
                options[a].style.backgroundColor = "lightgreen";
                options[0].style.pointerEvents = "none";
                options[1].style.pointerEvents = "none";
                options[2].style.pointerEvents = "none";
                document.querySelector(".next").style.pointerEvents = "all";
                document.querySelector(".next").style.backgroundColor = "lightgreen";
                questions[i].setAttribute("completed", "true");
                correct++;
            }
            else {
                options[a].style.backgroundColor = "lightcoral";
                options[0].style.pointerEvents = "none";
                options[1].style.pointerEvents = "none";
                options[2].style.pointerEvents = "none";
                document.querySelector(".next").style.pointerEvents = "all";
                document.querySelector(".next").style.backgroundColor = "lightgreen";
                questions[i].setAttribute("completed", "true");
                incorrect++;
            }
        });
    }
}

//Navigating to next question
document.querySelector(".next").addEventListener("click", () => {
    if (current_question + 1 < questions.length) {
        questions[current_question].style.cssText = "visibility: hidden; opacity: 0";

        current_question++;
        questions[current_question].style.cssText = "visibility: visible; opacity: 1";

        document.querySelector(".prev").style.pointerEvents = "all";
        document.querySelector(".prev").style.backgroundColor = "lightgreen";
        if (questions[current_question].getAttribute("completed") !== "true") {
            document.querySelector(".next").style.pointerEvents = "none";
            document.querySelector(".next").style.backgroundColor = "lightcoral";
        }
        if (document.querySelector(".quiz-result").getAttribute("finished") == "true" && current_question + 1 >= questions.length) {
            document.querySelector(".next").innerHTML = "Pontszám";
        }
        if (current_question + 1 >= questions.length && document.querySelector(".quiz-result").getAttribute("finished") !== "true") {
            document.querySelector(".next").innerHTML = "Befejezés";
        }
    }
    else {
        document.querySelector(".end-score").style.display = "block";
        document.querySelector(".incorrect").innerHTML = "<span>Helytelen válaszok száma: </span>" + "<span style=\"color:red\">" + incorrect + "</span>";
        document.querySelector(".correct").innerHTML = "<span>Helyes válaszok száma: </span>" + "<span style=\"color:green\">" + correct + "</span>";
        document.querySelector(".next").innerHTML = "Pontszám";
        document.querySelector(".quiz-result").setAttribute("finished", "true");
    }
    document.querySelector(".question-counter").innerHTML = question_counter + current_question + "/" + questions.length
});

//Navigating to previous question
document.querySelector(".prev").addEventListener("click", () => {
    if (current_question - 1 >= 0) {
        questions[current_question].style.cssText = "visibility: hidden; opacity: 0";
        current_question--;
        questions[current_question].style.cssText = "visibility: visible; opacity: 1";
        document.querySelector(".next").style.pointerEvents = "all";
        document.querySelector(".next").style.backgroundColor = "lightgreen";
        document.querySelector(".next").innerHTML = "Tovább";
    }
    if (current_question == 0){
        document.querySelector(".prev").style.pointerEvents = "none";
        document.querySelector(".prev").style.backgroundColor = "lightcoral";
    }
    document.querySelector(".question-counter").innerHTML = question_counter + current_question + "/" + questions.length
});

//Closing final score window
document.querySelector(".close").addEventListener("click", () => {
    document.querySelector(".end-score").style.display = "none";
});

//Showing correct answers
document.querySelector(".show").addEventListener("click", () => {
    document.querySelector(".end-score").style.display = "none";
    for (let i = 0; i < questions.length; i++) {
        let options = questions[i].getElementsByClassName("opt");
        for (let a = 0; a < options.length; a++) {
                if (options[a].getAttribute("right") == "true") {
                    options[a].style.backgroundColor = "lightgreen";
                };
         }
    }
});
