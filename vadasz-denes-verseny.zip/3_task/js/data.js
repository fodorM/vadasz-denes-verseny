let data = {
    'questions': [
        {
            'question': 'Ki szólalt fel a nukleális fegyverkezés ellen?',
            'option1': {
                'answer': 'Szilárd Leó',
                'right': 'true'
            },
            'option2': {
                'answer': 'Goldmark Péter',
                'right': 'false'
            },
            'option3': {
                'answer': 'Neumann János',
                'right': 'false'
            }
        },
        {
            'question': 'Hol izolálták először az aszkorbinsavat?',
            'option1': {
                'answer': 'Budapesten',
                'right': 'false'
            },
            'option2': {
                'answer': 'Szegeden',
                'right': 'true'
            },
            'option3': {
                'answer': 'Debrecenben',
                'right': 'false'
            }
        },
        {
            'question': 'Melyik ország egyetemének hívásának nem tett eleget Semmelweis Ignác?',
            'option1': {
                'answer': 'Németország',
                'right': 'false'
            },
            'option2': {
                'answer': 'Franciaország',
                'right': 'false'
            },
            'option3': {
                'answer': 'Svájc',
                'right': 'true'
            }
        },
        {
            'question': 'Hány évesen lett az MTA rendes tagja Eötvös Lóránd?',
            'option1': {
                'answer': '32',
                'right': 'false'
            },
            'option2': {
                'answer': '35',
                'right': 'true'
            },
            'option3': {
                'answer': '38',
                'right': 'false'
            }
        },
        {
            'question': 'Hol vett részt nemzetközi kongresszuson  1883-ban Eötvös Loránd?',
            'option1': {
                'answer': 'Bécs',
                'right': 'false'
            },
            'option2': {
                'answer': 'Párizs',
                'right': 'true'
            },
            'option3': {
                'answer': 'Washington, D.C.',
                'right': 'false'
            }
        }
    ]
}
