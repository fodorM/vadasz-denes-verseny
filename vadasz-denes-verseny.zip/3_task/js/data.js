let data = {
    'questions': [
        {
            'question': 'Where does Einstein come from?',
            'option1': {
                'answer': 'Germany',
                'right': 'true'
            },
            'option2': {
                'answer': 'Hungary',
                'right': 'false'
            },
            'option3': {
                'answer': 'USA',
                'right': 'false'
            }
        },
        {
            'question': 'What does Einstein do?',
            'option1': {
                'answer': 'Chemist',
                'right': 'false'
            },
            'option2': {
                'answer': 'Physics',
                'right': 'true'
            },
            'option3': {
                'answer': 'Biology',
                'right': 'false'
            }
        },
        {
            'question': 'What does e=mc2 mean?',
            'option1': {
                'answer': 'Who knows',
                'right': 'false'
            },
            'option2': {
                'answer': 'Nothing',
                'right': 'false'
            },
            'option3': {
                'answer': 'Energy equals mass times the speed of light squared',
                'right': 'true'
            }
        },
        {
            'question': 'What is Einstein\'s last name?',
            'option1': {
                'answer': 'George',
                'right': 'false'
            },
            'option2': {
                'answer': 'Albert',
                'right': 'true'
            },
            'option3': {
                'answer': 'Picasso',
                'right': 'false'
            }
        }
        
    ]
}
